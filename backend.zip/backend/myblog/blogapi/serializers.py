from rest_framework import serializers
from .model import datapost,profile
from django.contrib.auth import get_user_model

User = get_user_model()
class userserializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id','username','first_name',"last_name",'email')

class profileSerilizer(serializers.ModelSerializer):
    class Meta:
        model= profile
        fields= "__all__"
        read_only_fields = ['user']
    def to_representation(self,instance):
        data = super().to_representation(instance)
        data['user'] = userserializer(instance.user).data
        return data              
class datapostserializer(serializers.ModelSerializer):
    class Meta:
        model = datapost
        fields = "__all__"
        read_only_fields = ['user']
        depth = 1
    
    def to_representation(self,instance):
        data = super().to_representation(instance)
        data['user'] = profileSerilizer(instance.user.profile).data
        return data    
        
        