from django.contrib import admin
from blogapi.model import datapost,profile
# Register your models here.
admin.site.register(datapost)
admin.site.register(profile)