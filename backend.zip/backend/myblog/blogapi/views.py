from django.shortcuts import render
from rest_framework import viewsets
from .model import datapost,profile
from .serializers import datapostserializer,profileSerilizer
from rest_framework.response import Response
from rest_framework import authentication, permissions
from rest_framework import generics
from rest_framework.authentication import TokenAuthentication
from rest_framework import views 
from django.contrib.auth.models import User
from rest_framework.response import Response
from django.http import JsonResponse
from .model import profile  

# Create your views here.
class blogpostview(generics.ListCreateAPIView):
    queryset = datapost.objects.all()
    serializer_class = datapostserializer
    permission_classes = [permissions.AllowAny]
    
    
class blogupdatedeleteview(generics.RetrieveUpdateDestroyAPIView):
    queryset = datapost.objects.all()
    serializer_class = datapostserializer
    permission_classes = [permissions.AllowAny]
    lookup_field = 'id'    
    
class profiletoken(views.APIView):
    permission_classes=[permissions.IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    
    def get(self,request):
        # response = JsonResponse({'message': "request is get",'username':serializer.data})
        user = request.user
        
        query = profile.objects.get(user = user )
        serializer = profileSerilizer(query)
        return Response({'message': "request is get",'username':serializer.data })
        
        
            