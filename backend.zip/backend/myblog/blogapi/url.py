
from django.urls import path
from .views import blogpostview,blogupdatedeleteview

urlpatterns = [
    path('blogdata/',blogpostview.as_view(),name="blogdata"),
    path('blogdata/<int:id>/',blogupdatedeleteview.as_view(),name="blogpost"),
    
]